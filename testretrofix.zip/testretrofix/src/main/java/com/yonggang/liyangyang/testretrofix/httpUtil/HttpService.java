package com.yonggang.liyangyang.testretrofix.httpUtil;

import com.yonggang.liyangyang.testretrofix.response.HttpResult;

import retrofit2.http.POST;
import rx.Observable;

/**
 * Created by liyangyang on 17/3/14.
 * 所有的接口都写在一个Interface中，方便管理
 */
public interface HttpService {
    @POST("category_list")
    Observable<HttpResult<String>> category_list();
}
